# Lifehacker - Projeto Django (esqueleto)

Projeto Django básico para um blog chamado **Lifehacker**.

## Conteúdo
- Projeto Django `lifehacker/`
- App `blog/` com model `Post`, CRUD (criar/editar/excluir), upload de imagem.
- Templates em `templates/blog/`
- Arquivos estáticos em `static/`
- Banco SQLite: `db.sqlite3` será criado quando rodar migrations.

## Como rodar localmente
1. Crie e ative um virtualenv.
2. Instale dependências:
   ```bash
   pip install Django==4.2
   ```
3. Execute:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py runserver
   ```
4. Acesse http://127.0.0.1:8000/

## Observações
- Substitua `SECRET_KEY` em `lifehacker/settings.py` antes de colocar em produção.
- Configurações de produção, `collectstatic`, Gunicorn/Nginx e armazenamento de mídia não estão incluídos.


## Autenticação
- Rotas de autenticação padrão do Django disponíveis em `/accounts/` (login, logout, password reset).
- Página de registro em `/register/`.
- Criar/editar/excluir posts agora requer usuário autenticado.
- URLs úteis:
  - `/accounts/login/` - login
  - `/accounts/logout/` - logout
  - `/register/` - registro
