document.addEventListener('DOMContentLoaded', () => {
  const list = document.getElementById('posts-list');
  if (!list) return;

  fetch('/api/posts/')
    .then(resp => resp.json())
    .then(data => {
      list.innerHTML = '';
      data.forEach(p => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.href = `/post/${p.slug}/`;
        a.textContent = p.title;
        const small = document.createElement('small');
        small.textContent = ' ' + new Date(p.created).toLocaleString();
        li.appendChild(a);
        li.appendChild(small);
        list.appendChild(li);
      });
    })
    .catch(err => {
      console.error('Erro ao carregar posts', err);
    });
});
