from django.db import models
from django.urls import reverse
from django.utils import timezone

class Post(models.Model):
    title = models.CharField('Título', max_length=200)
    slug = models.SlugField('Slug', max_length=200, unique=True)
    body = models.TextField('Conteúdo')
    created = models.DateTimeField('Criado', default=timezone.now)
    updated = models.DateTimeField('Atualizado', auto_now=True)
    published = models.BooleanField('Publicado', default=True)
    image = models.ImageField('Imagem', upload_to='posts/', null=True, blank=True)

    class Meta:
        ordering = ['-created']
        verbose_name = 'Post'
        verbose_name_plural = 'Posts'

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('blog:post_detail', kwargs={'slug': self.slug})
